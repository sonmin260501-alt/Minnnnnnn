package com.example.worldclockwallpaper;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(48, 80, 48, 48);
        TextView t = new TextView(this);
        t.setText("World Clock\n\n서울 · 멕시코시티 · 마드리드\n테구시갈파 · 보고타 · 상파울루\n\n실시간 시계가 움직이는 라이브 배경화면");
        t.setTextSize(20);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.rgb(5, 10, 25));
        box.addView(t);
        Button set = new Button(this);
        set.setText("라이브 배경화면으로 설정");
        set.setOnClickListener(v -> {
            Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, WorldClockWallpaperService.class));
            startActivity(i);
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 40;
        box.addView(set, p);
        setContentView(box);
    }
}
