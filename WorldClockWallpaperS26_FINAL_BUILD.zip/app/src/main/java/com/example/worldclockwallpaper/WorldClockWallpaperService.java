package com.example.worldclockwallpaper;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class WorldClockWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new ClockEngine(); }

    private class ClockEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        private final String[] zones = {
                "Asia/Seoul", "America/Mexico_City", "Europe/Madrid",
                "America/Bogota", "America/Tegucigalpa", "America/Sao_Paulo"
        };
        private final String[] names = {
                "서울", "멕시코시티", "마드리드", "보고타", "테구시갈파", "상파울루"
        };
        private final String[] sub = {
                "Corea del Sur", "México", "España", "Colombia", "Honduras", "Brasil"
        };
        private final int[] ringColors = {
                Color.rgb(40,160,255), Color.rgb(0,235,210), Color.rgb(255,205,50),
                Color.rgb(235,65,215), Color.rgb(35,165,255), Color.rgb(255,210,55)
        };
        private final float[] cx = {208, 512, 816, 208, 512, 816};
        private final float[] cy = {249, 249, 249, 1040, 1040, 1040};
        private Bitmap background;
        private boolean visible;
        private final Runnable tick = new Runnable() {
            @Override public void run() {
                if (visible) {
                    drawFrame();
                    handler.postDelayed(this, 1000L - (System.currentTimeMillis() % 1000L));
                }
            }
        };

        ClockEngine() {
            background = BitmapFactory.decodeResource(getResources(), R.drawable.world_clock_background);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setStrokeCap(Paint.Cap.ROUND);
        }

        @Override public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            visible = true;
            drawFrame();
            handler.removeCallbacks(tick);
            handler.postDelayed(tick, 1000L);
        }

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            handler.removeCallbacks(tick);
            if (visible) {
                drawFrame();
                handler.postDelayed(tick, 1000L - (System.currentTimeMillis() % 1000L));
            }
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            drawFrame();
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            handler.removeCallbacks(tick);
            super.onSurfaceDestroyed(holder);
        }

        @Override public void onDestroy() {
            visible = false;
            handler.removeCallbacks(tick);
            if (background != null && !background.isRecycled()) background.recycle();
            super.onDestroy();
        }

        private void drawFrame() {
            if (!visible) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c == null) return;
                int w = c.getWidth(), h = c.getHeight();
                float sx = w / 1024f, sy = h / 1536f;
                c.save();
                c.scale(sx, sy);
                if (background != null && !background.isRecycled()) {
                    c.drawBitmap(background, null, new Rect(0, 0, 1024, 1536), p);
                } else c.drawColor(Color.BLACK);

                Date now = new Date();
                for (int i = 0; i < 6; i++) {
                    drawClock(c, i, now);
                    drawInfo(c, i, now);
                }
                c.restore();
            } finally {
                if (c != null) holder.unlockCanvasAndPost(c);
            }
        }

        private void drawClock(Canvas c, int i, Date now) {
            float x = cx[i], y = cy[i], r = 84f;
            // Replace the artwork's static clock face with a clean live face.
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(3, 12, 28));
            c.drawCircle(x, y, r - 3, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(4f);
            p.setColor(ringColors[i]);
            c.drawCircle(x, y, r, p);
            p.setStrokeWidth(1.5f);
            p.setColor(Color.WHITE);
            for (int n = 0; n < 12; n++) {
                double a = Math.toRadians(n * 30 - 90);
                float x1 = x + (float)Math.cos(a) * (r - 10);
                float y1 = y + (float)Math.sin(a) * (r - 10);
                float x2 = x + (float)Math.cos(a) * (r - 17);
                float y2 = y + (float)Math.sin(a) * (r - 17);
                c.drawLine(x1, y1, x2, y2, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(13f);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            for (int n = 1; n <= 12; n++) {
                double a = Math.toRadians(n * 30 - 90);
                float tx = x + (float)Math.cos(a) * (r - 27);
                float ty = y + (float)Math.sin(a) * (r - 27) + 5;
                c.drawText(String.valueOf(n), tx, ty, p);
            }

            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone(zones[i]), Locale.US);
            cal.setTime(now);
            float sec = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f;
            float min = cal.get(Calendar.MINUTE) + sec / 60f;
            float hour = (cal.get(Calendar.HOUR) % 12) + min / 60f;
            hand(c, x, y, hour * 30f, r * .48f, 6f, Color.WHITE);
            hand(c, x, y, min * 6f, r * .68f, 4f, Color.WHITE);
            hand(c, x, y, sec * 6f, r * .78f, 2f, Color.RED);
            p.setColor(Color.WHITE); c.drawCircle(x, y, 4f, p);
            p.setColor(Color.RED); c.drawCircle(x, y, 2f, p);
        }

        private void hand(Canvas c, float x, float y, float degrees, float len, float width, int color) {
            double a = Math.toRadians(degrees - 90);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(width);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(color);
            c.drawLine(x, y, x + (float)Math.cos(a) * len, y + (float)Math.sin(a) * len, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawInfo(Canvas c, int i, Date now) {
            float x = cx[i], base = cy[i] + 145;
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(23f);
            p.setColor(Color.WHITE);
            c.drawText(names[i], x, base, p);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(15f);
            c.drawText("(" + sub[i] + ")", x, base + 21, p);
            TimeZone tz = TimeZone.getTimeZone(zones[i]);
            SimpleDateFormat f = new SimpleDateFormat("HH:mm:ss", Locale.US);
            f.setTimeZone(tz);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(29f);
            c.drawText(f.format(now), x, base + 62, p);
            SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            d.setTimeZone(tz);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(14f);
            c.drawText(d.format(now), x, base + 84, p);
        }
    }
}
